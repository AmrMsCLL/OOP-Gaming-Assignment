#include <bits/stdc++.h>
#ifndef _BoardGame_CLASSES_H
#define _BoardGame_CLASSES_H
using namespace std;

class Board {
protected:
    int n_rows, n_cols;
    char** board;
    int  n_moves = 0;
public:
    virtual bool update_board (int x, int y, char symbol) = 0;
    virtual bool is_winner() = 0;
    virtual bool is_draw() = 0;
    virtual void display_board() = 0;
    virtual bool game_is_over() = 0;
};

class C4_Board:public Board {
private:
    int next_empty[7] = {5,5,5,5,5,5,5};
public:
    C4_Board ();
    bool update_board (int x, int y, char mark);
    void undo_move(int col);
    void display_board();
    bool is_winner();
    bool is_draw();
    bool game_is_over();
};

class Player{
protected:        
    string name;
    char symbol;
public:
    Player(){}
    Player(char symbol); // Needed for computer players
    Player(int order, char symbol);
    
    virtual void get_move(int& x, int& y);
    // virtual void C4_get_move(int &y);
    string to_string();
    char get_symbol();
};

class C4_Player {
    protected:        
    string name;
    char symbol;
public:
    C4_Player(char symbol); // Needed for computer players
    C4_Player(int order, char symbol);
    
    virtual void get_move(int& x, int& y);
    // virtual void C4_get_move(int &y);
    string to_string();
    char get_symbol();
};

class RandomPlayer: public Player {
protected:
    int dimension;
public:
    RandomPlayer (char symbol, int dimension);
    void get_move(int& x, int& y);
};

class C4_RandomPlayer: public C4_Player {
public:
    C4_RandomPlayer(char symbol);
    void get_move(int&x, int&y);
};

class GameManager {
private:
    Board* boardPtr;
    Player* players[2];
public:
    GameManager(Board*, Player* playerPtr[2]);
    void run();
};

class C4_GameManager{ 
private:
    Board* boardPtr;
    C4_Player* players[2];
public:
    C4_GameManager(Board*, C4_Player* playerPtr[2]);
    void run();
};

#endif