#ifndef _CLASSES_HEADER_H
#define _CLASSES_HEADER_H
#include <bits/stdc++.h>
using namespace std;

class Board {
protected:
public:
    int n_rows, n_cols;
    char** board;
    int  n_moves = 0;
    virtual bool update_board (int x, int y, char symbol) = 0;
    virtual bool is_winner() = 0;
    virtual bool is_draw() = 0;
    virtual void reset_board() = 0;
    virtual bool game_is_over() = 0;
};
class Player {
protected:        
    string name;
    char symbol;
public:
    Player(){}
    Player(char symbol);
    Player(int order, char symbol);
    
    virtual void get_move(int& x, int& y);
    string to_string();
    char get_symbol();
};
class RandomPlayer:public Player {
protected:
    int dimension;
public:
    RandomPlayer (char symbol, int dimension);
    void get_move(int& x, int& y);
};

// Normal XO Classes (made by doctor)
class X_O_Board:public Board {
public:
   X_O_Board ();
   bool update_board (int x, int y, char mark);
   void reset_board();
   bool is_winner();
   bool is_draw();
   bool game_is_over();
};

// Pyramid XO Classes
class Pyramid_Board:public Board {
public:
    Pyramid_Board ();
    bool update_board (int x, int y, char mark);
    void display_board();
    bool is_winner();
    bool is_draw();
    bool game_is_over();
};
class Pyramid_Player {
protected:
    string name;
    char symbol;
public:
    Pyramid_Player (char symbol);
    Pyramid_Player (int order, char symbol);
    virtual void get_move(int& x, int& y);
    string to_string();
    char get_symbol();
};
class Pyramid_RandomPlayer:public Pyramid_Player{
protected:
        int dimension;
public: 
    Pyramid_RandomPlayer (char symbol, int dimension);
    void get_move(int& x, int& y);   
};


// Four in a row Classes
class C4_Board:public Board {
private:
    int next_empty[7] = {5,5,5,5,5,5,5};
public:
   C4_Board ();
   bool update_board (int x, int y, char mark);
   void reset_board();
   bool is_winner();
   bool is_draw();
   bool game_is_over();
};
class C4_Player {
protected:        
    string name;
    char symbol;
public:
    C4_Player(char symbol);
    C4_Player(int order, char symbol);
    
    virtual void get_move(int& x, int& y);
    string to_string();
    char get_symbol();
};
class C4_AI: public C4_Player{
protected:
    C4_Board* board;
public:
    C4_AI(C4_Board* bo, char s);
    void get_move(int& x, int& y);
    int findLowestEmptyRow(int col);
    int minimax(int d, bool isMaximizing, int alpha, int beta);
    int evaluateBoard();
    int evaluatePosition(int row, int col, int deltaRow, int deltaCol);
    int scoreForAdjacentPieces(int row, int col);
    int centerColumnScore();
    int blockingScore();
    int winningScore();
};

// 5x5 X O Classes
class XO5_Board:public Board {
protected:
    int counter = 0;
    int count1 = 0;
    int count2 = 0;
    int count = 0;
public:
   XO5_Board ();
   bool update_board (int x, int y, char mark);
   void reset_board();
   bool is_draw();
   bool is_winner();
   bool game_is_over();
};
class XO5_Player {
protected:
    string name;
    char symbol;
public:
    XO5_Player (char symbol);
    XO5_Player (int order, char symbol);
    virtual void get_move(int& x, int& y);
    string to_string();
    char get_symbol();
};
class XO5_RandomPlayer:public XO5_Player {
protected:
    int dimension;
public:
    XO5_RandomPlayer (char symbol, int dimension);
    void get_move (int& x, int& y);    
};

#endif
