#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "Classes_Header.h"

#include <QPushButton>
#include <QSignalMapper>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    setupGameC4();
    setupGameTTT();
    setupGameXO5();
}

void MainWindow::setupGameC4() {
    QGridLayout* gridC4 = ui->gridC4;

    QSignalMapper* signalMapper = new QSignalMapper(this);
    for (int col = 0; col < 7; ++col) {
        QPushButton* colButton = new QPushButton(QString::number(col + 1), this);
        gridC4->addWidget(colButton, 0, col);

        connect(colButton, SIGNAL(clicked()), signalMapper, SLOT(map()));
        signalMapper->setMapping(colButton, col + 1);
    }
    connect(signalMapper, SIGNAL(mappedInt(int)), this, SLOT(playerMoveC4(int)));

    for (int row = 1; row < 7; ++row) {
        for (int col = 0; col < 7; ++col) {
            labelBoardC4[row - 1][col] = new QLabel(this);
            labelBoardC4[row - 1][col]->setText(" ");
            labelBoardC4[row - 1][col]->setAlignment(Qt::AlignCenter);
            gridC4->addWidget(labelBoardC4[row - 1][col], row, col);
        }
    }

    boardC4 = new C4_Board();
    playersC4[0] = new C4_Player(1, 'x');
    playersC4[1] = new C4_Player(2, 'o');
    playersC4[2] = new C4_AI(boardC4,'o');
    currentPlayerC4 = 0;
}

void MainWindow::resetGameC4(){
    boardC4->reset_board();

    updateLabelBoardC4();

    while (QLayoutItem* item = ui->gridC4->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            delete widget;
        } else {
            delete item;
        }
    }
    setupGameC4();
    currentPlayerC4 = 0;
    ui->statusC4->setText("Status: Game Reset.");
}

void MainWindow::playerMoveC4(int y) {
    if (currentPlayerC4 == -1) {
        return;
    }

    char currentPlayerSymbol =  playersC4[currentPlayerC4]->get_symbol();
    if (boardC4->update_board(0, y, currentPlayerSymbol)) {
        updateLabelBoardC4();

        if (boardC4->is_winner()) {
            ui->statusC4->setText("Status: Player " + QString(currentPlayerSymbol).toUpper() + " Wins!");
            currentPlayerC4 = -1;
            return;
        }
        if (boardC4->is_draw()){
            ui->statusC4->setText("Status: Draw!");
            currentPlayerC4 = -1;
            return;
        }

        if (!ui->checkBox_3->isChecked()) {
            currentPlayerC4 = 1 - currentPlayerC4;
        }

        if(ui->checkBox_3->isChecked() && currentPlayerC4 == 0){
            int player2X, player2Y;
            playersC4[2]->get_move(player2X, player2Y);

            while (!boardC4->update_board(0, player2Y, playersC4[2]->get_symbol())) {
                playersC4[2]->get_move(player2X, player2Y);
            }

            updateLabelBoardC4();

            if (boardC4->is_winner()) {
                ui->statusC4->setText("Status: You lose!");
                currentPlayerC4 = -1;
                return;
            }
            if (boardC4->is_draw()){
                ui->statusC4->setText("Status: Draw!");
                currentPlayerC4 = -1;
                return;
            }
        }
    }
    else {
        ui->statusC4->setText("Status: Invalid move!");
    }
}

void MainWindow::updateLabelBoardC4() {
    for (int row = 1; row < 7; ++row) {
        for (int col = 0; col < 7; ++col) {
            labelBoardC4[row - 1][col]->setText(QString(boardC4->board[row - 1][col]));
        }
    }
}

void MainWindow::setupGameTTT() {

    QGridLayout* gridTTT = ui->gridTTT;

    QSignalMapper* signalMapper = new QSignalMapper(this);
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                buttonBoardTTT[row][col] = new QPushButton(this);
                gridTTT->addWidget(buttonBoardTTT[row][col], row, col);
                int encodedPos = row * 3 + col;
            connect(buttonBoardTTT[row][col], SIGNAL(clicked()), signalMapper, SLOT(map()));
            signalMapper->setMapping(buttonBoardTTT[row][col], encodedPos);
            }
        }
        connect(signalMapper, SIGNAL(mappedInt(int)), this, SLOT(playerMoveTTT(int)));

        boardTTT = new X_O_Board();
        playersTTT[0] = new Player(1, 'x');
        playersTTT[1] = new Player(2, 'o');
        playersTTT[2] = new RandomPlayer('o', 3);
        currentPlayerTTT = 0;
}

void MainWindow::resetGameTTT() {
    boardTTT->reset_board();

    while (QLayoutItem* item = ui->gridTTT->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            delete widget;
        } else {
            delete item;
        }
    }
    setupGameTTT();
    currentPlayerTTT = 0;
    ui->statusTTT->setText("Status: Game reset.");

}

void MainWindow::playerMoveTTT(int encodedPos) {
    int x = encodedPos / 3;
    int y = encodedPos % 3;

    if (currentPlayerTTT == -1) {
        return;
    }

    char currentPlayerSymbol =  playersTTT[currentPlayerTTT]->get_symbol();
    if (boardTTT->update_board(x, y, currentPlayerSymbol)) {
        updatePushBoardTTT();

        if (boardTTT->is_winner()) {
        ui->statusTTT->setText("Status: Player " + QString(currentPlayerSymbol).toUpper() + " Wins!");
        currentPlayerTTT = -1;
        return;
        }
        if (boardTTT->is_draw()){
        ui->statusTTT->setText("Status: Draw!");
        currentPlayerTTT = -1;
        return;
        }

        if (!ui->checkBox_2->isChecked()) {
        currentPlayerTTT = 1 - currentPlayerTTT;
        }

        if(ui->checkBox_2->isChecked() && currentPlayerTTT == 0){
        int player2X, player2Y;
        playersTTT[2]->get_move(player2X, player2Y);

        while (!boardTTT->update_board(player2X, player2Y, playersTTT[2]->get_symbol())) {
                playersTTT[2]->get_move(player2X, player2Y);
        }

        updatePushBoardTTT();

        if (boardTTT->is_winner()) {
                ui->statusTTT->setText("Status: You lose!");
                currentPlayerTTT = -1;
                return;
        }
        if (boardTTT->is_draw()){
                ui->statusTTT->setText("Status: Draw!");
                currentPlayerTTT = -1;
                return;
        }
        }
    }
    else {
        ui->statusC4->setText("Status: Invalid move!");
    }
}

void MainWindow::updatePushBoardTTT() {
    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
        buttonBoardTTT[row][col]->setText(QString(boardTTT->board[row][col]));
        }
    }
}

void MainWindow::setupGameXO5() {
    QGridLayout* gridXO5 = ui->gridXO5;

    QSignalMapper* signalMapper = new QSignalMapper(this);
    for (int row = 0; row < 5; row++) {
        for (int col = 0; col < 5; col++) {
            buttonBoardXO5[row][col] = new QPushButton(this);
            gridXO5->addWidget(buttonBoardXO5[row][col], row, col);
            int encodedPos = row * 5 + col;
            connect(buttonBoardXO5[row][col], SIGNAL(clicked()), signalMapper, SLOT(map()));
            signalMapper->setMapping(buttonBoardXO5[row][col], encodedPos);
        }
    }
    connect(signalMapper, SIGNAL(mappedInt(int)), this, SLOT(playerMoveXO5(int)));

    boardXO5 = new XO5_Board();
    playersXO5[0] = new XO5_Player(1, 'x');
    playersXO5[1] = new XO5_Player(2, 'o');
    playersXO5[2] = new XO5_RandomPlayer('o', 5);
    currentPlayerXO5 = 0;

}

void MainWindow::resetGameXO5() {
    boardXO5->reset_board();

    while (QLayoutItem* item = ui->gridXO5->takeAt(0)) {
        // If the item is a widget, remove and delete it
        if (QWidget* widget = item->widget()) {
        delete widget;
        } else {
        delete item;
        }
    }
    setupGameXO5();
    currentPlayerXO5 = 0;
    ui->statusXO5->setText("Status: Game reset.");

}

void MainWindow::playerMoveXO5(int encodedPos) {
    int x = encodedPos / 5;
    int y = encodedPos % 5;
    int n_moves = 0;
    if (currentPlayerXO5 == -1) {
        ui->statusXO5->setText("Status: Game Is Over Stop Trying To Play!");
        return;
    }

    char currentPlayerSymbol = playersXO5[currentPlayerXO5]->get_symbol();
    if (boardXO5->update_board(x, y, currentPlayerSymbol)) {
        updatePushBoardXO5();
        n_moves++;

        if (!ui->checkBox_4->isChecked() || currentPlayerXO5 != 0) {
        currentPlayerXO5 = 1 - currentPlayerXO5;
        }
        else {
        int player2X, player2Y;
            playersXO5[2]->get_move(player2X, player2Y);
        while (!boardXO5->update_board(player2X, player2Y, playersXO5[2]->get_symbol())) {
            playersXO5[2]->get_move(player2X, player2Y);
        }
        }
        updatePushBoardXO5();

        if (boardXO5->n_moves == 24) {
            if (boardXO5->is_winner()){
                if (boardXO5->is_draw()) {
                    ui->statusXO5->setText("Status: Draw!");
                    currentPlayerXO5 = -1;
                }
                else if (boardXO5->is_winner()) {
                    ui->statusXO5->setText("Status: Player X  Wins!");
                    currentPlayerXO5 = -1;
                }
            }
                else if (!boardXO5->is_winner()){
                    ui->statusXO5->setText("Status: Player O  Wins!");
                    currentPlayerXO5 = -1;
                }
        }
    }
    else {
        ui->statusXO5->setText("Status: Invalid move!");
    }
}

void MainWindow::updatePushBoardXO5() {
    for (int row = 2; row < 7; row++) {
        for (int col = 2; col < 7; col++) {
        buttonBoardXO5[row - 2][col - 2]->setText(QString(boardXO5->board[row][col]));
        }
    }
}

MainWindow::~MainWindow() {
    delete ui;
    if (boardC4 != nullptr) {
        delete boardC4;
    }
    for (auto &player : playersC4) {
        if (player != nullptr) {
            delete player;
            player = nullptr;
        }
    }

    if (boardTTT != nullptr) {
        delete boardTTT;
    }
    for (auto &player : playersTTT) {
        if (player != nullptr) {
            delete player;
            player = nullptr;
        }
    }
}

void MainWindow::on_button1TTT_clicked(){
    ui->stackedWidget->setCurrentIndex(2);
}
void MainWindow::on_button0PTTT_clicked(){
    ui->stackedWidget->setCurrentIndex(1);
}
void MainWindow::on_buttonPTTBack_clicked(){
    ui->stackedWidget->setCurrentIndex(0);
}
void MainWindow::on_button2C4_clicked(){
    ui->stackedWidget->setCurrentIndex(3);
}
void MainWindow::on_buttonC4Back_clicked(){
    resetGameC4();
    ui->stackedWidget->setCurrentIndex(0);
}
void MainWindow::on_button45TTT_clicked(){
    ui->stackedWidget->setCurrentIndex(4);
}
void MainWindow::on_buttonTTTBack_clicked(){
    resetGameTTT();
    ui->stackedWidget->setCurrentIndex(0);
}
void MainWindow::on_buttonXO5Back_clicked(){
    resetGameXO5();
    ui->stackedWidget->setCurrentIndex(0);
}
void MainWindow::on_buttonC4Reset_clicked(){
    resetGameC4();
}
void MainWindow::on_buttonTTTReset_clicked(){
    resetGameTTT();
}
void MainWindow::on_buttonXO5Reset_clicked(){
    resetGameXO5();
}
