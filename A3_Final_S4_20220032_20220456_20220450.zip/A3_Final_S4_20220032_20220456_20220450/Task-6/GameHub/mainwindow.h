#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include "Classes_Header.h"
#include "qpushbutton.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void playerMoveC4(int column);
    void playerMoveTTT(int encodedPos);
    void playerMoveXO5(int encodedpos);

    void on_button2C4_clicked();
    void on_buttonC4Back_clicked();
    void on_button0PTTT_clicked();
    void on_buttonPTTBack_clicked();
    void on_button1TTT_clicked();
    void on_button45TTT_clicked();
    void on_buttonTTTBack_clicked();
    void on_buttonXO5Back_clicked();
    void on_buttonC4Reset_clicked();
    void on_buttonTTTReset_clicked();
    void on_buttonXO5Reset_clicked();

private:
    Ui::MainWindow *ui;

    QPushButton* buttonBoardTTT[3][3];
    X_O_Board* boardTTT;
    Player* playersTTT[3];
    void setupGameTTT();
    void resetGameTTT();
    void updatePushBoardTTT();
    int currentPlayerTTT;

    QLabel* labelBoardC4[7][7];
    C4_Board* boardC4;
    C4_Player* playersC4[3];
    void setupGameC4();
    void resetGameC4();
    void updateLabelBoardC4();
    int currentPlayerC4;

    QPushButton* buttonBoardXO5[5][5];
    XO5_Board* boardXO5;
    XO5_Player* playersXO5[3];
    void setupGameXO5();
    void resetGameXO5();
    void updatePushBoardXO5();
    int currentPlayerXO5;

};

#endif // MAINWINDOW_H
