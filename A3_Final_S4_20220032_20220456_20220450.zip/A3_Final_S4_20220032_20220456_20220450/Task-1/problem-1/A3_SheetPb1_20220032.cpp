// File name: A3_SheetPb1_20220032
// Purpose:    Label Generator
// Author(s):  Ahmed Mohammed Saber
// ID(s):      20220032
// Section:    S4
// Date:       Dec.9


//-----------------------------------------------------
#include <iostream>
#include <utility>
#include <fstream>
#include <vector>
using namespace std;
//-----------------------------------------------------

class LabelGenerator
{
protected:
    string Label;
    int counter;

public:
    LabelGenerator(string l, int n);
    virtual string nextLabel();
};

//--------------------implementation---------------------------------

LabelGenerator ::LabelGenerator(string l, int n) : Label(l), counter(n) {}
string LabelGenerator ::nextLabel()
{
    return Label + " " + to_string(counter++); // increase the counter in every call of this operation
}

//-----------------------------------------------------

class FileLabelGenerator : public LabelGenerator
{
private:
    vector<string> fileContent;
    int lineCnt;

public:
    FileLabelGenerator(string l, int n, string f);
    string nextLabel();
};

//--------------------implementation---------------------------------

FileLabelGenerator ::FileLabelGenerator(string l, int n, string f) : LabelGenerator(l, n)
{

    //-----get the input from the file----//
    lineCnt = n == 0 ? n : n - 1;
    ifstream in(f);
    string line;

    if (in.is_open())
    {
        while (getline(in, line))
        {
            fileContent.push_back(line);
        }
        in.close();
    }
    else
    {
        throw("Unable to open file");
    }
}

//-----------------------------------------------------

string FileLabelGenerator ::nextLabel()
{ // the overloaded operation
    return Label + to_string(counter++) + " " + " " + fileContent[lineCnt++];
}

//-----------------------------------------------------

int main()
{
    LabelGenerator figureNumbers("Figure ", 1);
    LabelGenerator pointNumbers("P", 0);
    cout << "Figure numbers: ";
    for (int i = 0; i < 3; i++)
    {
        cout << figureNumbers.nextLabel();
        if (i != 2)
            cout << ", ";
    }
    cout << endl
         << "Point numbers: ";
    for (int i = 0; i < 5; i++)
    {
        cout << pointNumbers.nextLabel();
        if (i != 4)
            cout << ", ";
    }
    cout << endl
         << "More figures: ";
    for (int i = 0; i < 3; i++)
    {
        cout << figureNumbers.nextLabel();
        if (i != 2)
            cout << ", ";
    }
    cout << endl;
    FileLabelGenerator figureLabels("Figure ", 1, "labels.txt");
    cout << "Figure labels: ";
    for (int i = 0; i < 3; i++)
    {
        cout << figureLabels.nextLabel();
        if (i != 2)
            cout << ", ";
    }
}
