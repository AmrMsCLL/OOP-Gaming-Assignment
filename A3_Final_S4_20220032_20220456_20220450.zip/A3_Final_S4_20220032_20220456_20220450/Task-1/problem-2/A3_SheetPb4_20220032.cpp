// File name: A3_SheetPb4_20220032
// Purpose:    Set Manually implementation
// Author(s):  Ahmed Mohammed Saber
// ID(s):      20220032
// Section:    S4
// Date:       Dec.9


//-----------------------------------------------------
#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;

//--------------------------------declaration------------------------------------
template <class T>
class Set{
private:
    vector <T> container;
public:
    void insert(T dataType);
    void remove(T dataType);
    int size();
    bool Find(T dataType);
    T* array();
    T & operator [](int i);

};

//-------------------------implementation-------------------------------------------

template <class T>
T & Set<T>:: operator [](int i){
    return container[i];
}

template <class T>
void Set<T> :: insert(T dataType){
    if(find(container.begin(), container.end(), dataType) != container.end());
    else
        container.push_back(dataType);
    sort(container.begin(), container.end());
}


template <class T>
void Set<T> ::remove(T dataType) {
    auto it = find(container.begin(), container.end(),dataType);
    if(it != container.end()){
        container.erase(it);
    }
    sort(container.begin(), container.end());
}

template <class T>
int Set<T> ::size() {
    return container.size();
}

template <class T>
bool Set<T> ::Find(T dataType) {
    if(find(container.begin(), container.end(), dataType) != container.end()){
        return true;
    }
    return false;
}

template <class T>
T* Set<T> ::array() {
    T* arr = new T[container.size()];
    int i = 0;
    for (auto x : container) {
        arr[i++] = x;
    }
    return arr;
}

//------------------------creating an example class--------------------------------------------
class someClass{
private:
    int att1;
    string att2;
public:
    someClass(){att1 = 0, att2 = "null";};
    someClass(int n, string s) : att1(n), att2(s){};

    //----overloading 

    bool operator == (const someClass other){
        return(att1 == other.att1 && att2 == other.att2);
    }


    bool operator != (const someClass other){
        return !(*this == other);
    }

    // overloading this operator to make sort function work with this class
    bool  operator <(const someClass other){
        if(att1 != other.att1)
            return (att1 < other.att1);
        return(att2 < other.att2);
    }


};
//--------------------------------------------------------------------
int main() {

    Set<int> s;
    s.insert(1);
    s.insert(2);
    s.insert(-2);
    s.insert(4);
    s.insert(2);
    s.remove(2);
    cout<<s.size()<<"\n";
    int* v = s.array();
    for(int i = 0; i < 3; i++)
        cout<<v[i]<<"\n";



//     for (int i = 0; i < s.size(); ++i) {
//         cout<<s[i]<<"\n";
//     }

    Set<someClass> s2;
    someClass a(1, "ahmed");
    s2.insert(a);
    someClass b(2, "Amr");
    s2.insert(b);
    someClass c(1, "ahmed");
    s2.insert(c);
    cout<<s2.size();

}
