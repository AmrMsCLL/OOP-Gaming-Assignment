// File name:sheetPb3
// Purpose:getting a frequency table for a file
// Author(s):Medhat Ahmed Abdelkarim
// ID(s):20220456
// Section:S3/4
// Date:6/12/2023
#include <bits./stdc++.h>
using namespace std;
#include<fstream>
int main() {
    map<string,int>doc;
    vector<string>save;
    string word;
    string filename;
    cout<<"please enter the filename : "; cin>>filename;
    filename+=".txt"; // adding .txt so because it is in that format in the files
    ifstream myfile(filename); // getting the input from the desired file
    while(myfile>>word){
        transform(word.begin(), word.end(), word.begin(), ::tolower);  // transforming the whole word into lower case so that i don't encounter any problems
        if(ispunct(word.back())){
            word.pop_back();
            save.push_back(word);
        }
        else
            save.push_back(word);
    } // pushing the word into a vector to ease the next process
    for (int i = 0; i <save.size() ; ++i) {
        doc[save[i]]++;
    } // filling the map with the word from the file
    string input;
    while(input!="0") { // some user-friendly input
        cout << "if you want to see the full frequency table press 1 : \n";
        cout << "if you want to see a particular word with its number of occurrences press 2 : \n";
        cout << "if you want to exit press 0 \n ";
        cout << "enter your choice here please : ";
        cin >> input;
        if (input == "0") {
            break;
        } else if (input == "1") {
            auto ite = doc.begin();
            for (int i = 0; i < doc.size(); ++i) {
                cout << ite->first << " " << ite->second << "\n";
                ite++;
            }// printing the frequency table
        } else if (input == "2") {
            string words;
            cout<<"please enter the word that you are looking for : ";cin>>words;
            auto it = doc.find(words);
            if (it == doc.end()) {
                cout << "the word was not found in the document \n";
            } else
                cout << "the word " << words << " " << "was in the document " << it->second << " " << "times. \n";
        }
    } // printing the desired word with its number of occurences
    cout<<"have a nice day";

}
