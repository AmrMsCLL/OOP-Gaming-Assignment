// File name: A3_SheetPb5_20220450.cpp
// Purpose:  Assignment sheet problem 5 solution 
// Author(s): Amr Mohamed El-Sheriey
// ID(s): 20220450
// Section: S4
// Date: 10th december 23

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>

using namespace std;

class Process {
public:
    string name;
    DWORD pid;
    string status;
    string user;
    SIZE_T memoryUsage;

    Process(string n, DWORD p, SIZE_T m)
    :   name(move(n)), pid(p), memoryUsage(m) {
        status = "Running";
        user = "ME";        
    }

    void display() const {
        cout << name; for(int i = name.size(); i <= 50; i++){cout << ' ';}
        cout << "\t\t" << pid << "\t" << status << "  " << user << "\t" << memoryUsage << "\tKB" << "\t64-bit" << endl;
    }
};

class ProcessList {
private:
    vector<Process> processes;

    void parseLine(const string& line) {
        istringstream iss(line);
        vector<string> tokens;
        string token;

        while (iss >> token) {
            tokens.push_back(token);
        }

        // Check if we have enough tokens to parse
        if (tokens.size() >= 6) {
            string name = tokens[0];

            // Process ID
            DWORD pid = 0;
            try {
                pid = stoul(tokens[1]);
            } catch (const exception& e) {
                cerr << ""; //<< e.what() << endl;
                return;
            }

            // Memory usage
            SIZE_T memoryUsage = 0;
            try {
                string mem = tokens[4];
                mem.erase(remove(mem.begin(), mem.end(), ','), mem.end()); // Remove commas
                memoryUsage = stoul(mem);
            } catch (const exception& e) {
                cerr << "Error parsing memory usage: " << e.what() << endl;
                return;
            }

            processes.emplace_back(name, pid, memoryUsage);
        }
    }

public:
    void retrieveProcessesFromFile() {
        system("tasklist > processes.txt");
        ifstream file("processes.txt");
        if (!file.is_open()) {
            cerr << "Failed to open processes.txt" << endl;
            return;
        }
        string line;

        // Skip the header lines
        for (int i = 0; i < 3; ++i) {
            if (!getline(file, line)) {
                cerr << "Failed to read header line" << endl;
                return;
            }
        }

        // Read and parse each line
        while (getline(file, line)) {
            parseLine(line);
        }

        file.close();
        remove("processes.txt"); // optional 
    }

        void sortByName() {
        sort(processes.begin(), processes.end(), [](const Process &a, const Process &b) {
            return a.name < b.name;
        });
    }

    void sortByPID() {
        sort(processes.begin(), processes.end(), [](const Process &a, const Process &b) {
            return a.pid < b.pid;
        });
    }

    void sortByMemoryUsage() {
        sort(processes.begin(), processes.end(), [](const Process &a, const Process &b) {
            return a.memoryUsage < b.memoryUsage;
        });
    }

    void displayProcesses() const {
        for (const auto& process : processes) {
            process.display();
        }
    }

};

void ui_elements() {
    string space(56, ' ');
    cout << "Proccess" << space << "PID\tStatus   User\tMemory" << endl;
    string equal(110, '=');
    cout << equal << endl;
}

int main() {
    cout << "TASK MANAGER by Amr Mohammed El-Sheriey." << endl;
    ProcessList processList;
    processList.retrieveProcessesFromFile();

    char sort_type;
    cout << "How do you want to sort ?\n(1) for by name.\n(2) for by PID.\n(3) For by memory usage.\n";
    cin >> sort_type;

    if (sort_type == '1'){
        cout << "Processes sorted by name: " << endl;
        ui_elements();
        processList.sortByName();
    }
    else if (sort_type == '2'){
        cout << "\nProcesses sorted by PID: " << endl;
        ui_elements();
        processList.sortByPID();
    }
    else if (sort_type == '3'){
        cout << "\nProcesses sorted by memory usage: " << endl;
        ui_elements();
        processList.sortByMemoryUsage();
    }
    else {
        cout << "Invalid input" << endl;
        return 1;
    }

    processList.displayProcesses();
    return 0;
}
