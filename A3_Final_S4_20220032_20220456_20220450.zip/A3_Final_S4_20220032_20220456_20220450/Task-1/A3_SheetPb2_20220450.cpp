// File name: A3_SheetPb2_20220450.cpp 
// Purpose: Assignment sheet problem 2 solution 
// Author(s): Amr Mohamed El-Sheriey   
// ID(s): 20220450
// Section: S4
// Date: 10th december 23

#include <bits/stdc++.h> 
using namespace std;

class StringSet { 
private:
    vector<string> words;
public:
    // default constructor
    StringSet(){}
    // couldnt implement 2 constuctors so i had to improvise and make them both in one constructor 
    // Constructor for taking input from a file if it can open the file otherwise consider it a string
    StringSet(const string& str_filename) {
        ifstream file(str_filename);
        if(file.is_open()){ // if it can find a file in the directory and open it then it will treat it as a file
            string word;
            while (file >> word) {
                // Remove punctuation
                word.erase(remove_if(word.begin(), word.end(), ::ispunct), word.end());
                // Convert to lowercase
                transform(word.begin(), word.end(), word.begin(), ::tolower);
                // Store words in the vector
                words.push_back(word);
            }
            file.close(); // Close the file after reading
        } 
        else { // else it will treat it as a normal string and have fun with it
            istringstream iss(str_filename);
            string word;
            while (iss >> word){
                // Remove punctuation
                word.erase(remove_if(word.begin(), word.end(), ::ispunct), word.end());
                // Convert to lowercase
                transform(word.begin(), word.end(), word.begin(), ::tolower);
                // Store words in the vector
                words.push_back(word);
            }
        }
    }

    // member functions 
    void addToSet(const string& word){
        words.push_back(word);
    }
    void removeFromSet(const string& word){
        words.erase(remove(words.begin(), words.end(), word), words.end());
        }
    void clearSet(){
        words.clear();
    }
    int setSize() const {
        return words.size();
    }
    void printSet() const {
        for (const auto& word : words)
            cout << word << ' ';
        cout << endl;
    }
    
    // + and * overloading
    StringSet operator+(const StringSet& bruh){
        StringSet Res = *this;
        for (const auto& word : bruh.words) {
            if (find(Res.words.begin(), Res.words.end(), word) == Res.words.end()) {
                Res.words.push_back(word);
            }   
        }
        for (auto i = Res.words.begin(); i != Res.words.end(); i++) {
                    auto duplicates = find(i + 1, Res.words.end(), *i);
                    while (duplicates != Res.words.end()) {
                        Res.words.erase(duplicates);
                        duplicates = find(i + 1, Res.words.end(), *i);
                    }
        }
        return Res;
    }
    StringSet operator*(const StringSet& bruh){
        StringSet Res;
        for (const auto& word : this->words) {
            if(find(bruh.words.begin(), bruh.words.end(), word) != bruh.words.end()) {
                Res.words.push_back(word);
            }   
        }
        for (auto i = Res.words.begin(); i != Res.words.end(); i++) {
                    auto duplicates = find(i + 1, Res.words.end(), *i);
                    while (duplicates != Res.words.end()) {
                        Res.words.erase(duplicates);
                        duplicates = find(i + 1, Res.words.end(), *i);
                    }
        }
        return Res;
    }

    // Similarity function
    double similarity(const StringSet& bruh) const {
        StringSet tmp = *this;
        StringSet intersection = tmp * bruh;
        if((sqrt(setSize()) * sqrt(bruh.setSize()) == 0)) // if the (sqrt(setSize()) * sqrt(bruh.setSize() equals 0 then the output of the similarity will be nan so making a case that when compared to an empty string it returns 0
            return 0;
        else 
            return static_cast<double>(intersection.setSize()) / (sqrt(setSize()) * sqrt(bruh.setSize()));
    }
};

int main() {
    StringSet a("hello, bye, goodday, goodbye, UwU");
    StringSet b("hello, bye, goodbye, OwO");
    StringSet c = a + b;
    StringSet d = a * b;
    StringSet e = a;
    string filename = "test.txt";
    StringSet f(filename);
    // testing member functions 
    cout << a.setSize() << " : " << b.setSize() << " : " << c.setSize() << " : " << d.setSize() << endl; //a = 5 , b = 4 , c = 6 , d = 3
    cout << "c : " ; c.printSet();
    cout << "d : " ; d.printSet();
    cout << "f : " ; f.printSet();
    c.clearSet();
    cout << "empty c : "; c.printSet();
    cout << "removing 'hi' from d : ";d.removeFromSet("hi"); d.printSet();
    cout << "adding 'hallo' to d :"; d.addToSet("hallo"); d.printSet();
    cout << "a : "; a.printSet(); cout << "e : "; e.printSet();
    cout << "similarity between a:e : " << a.similarity(e) << endl;
    cout << "a : "; a.printSet(); cout << "d : "; d.printSet();
    cout << "similarity between a:d : " << a.similarity(d) << endl;
    cout << "similarity between a:c where c is an empty string : " << a.similarity(c) << endl;
}