// File name:sheetPb6
// Purpose:producing a replica for the game of life
// Author(s):Medhat Ahmed Abdelkarim
// ID(s):20220456
// Section:S3/4
// Date:7/12/2023
#include <iostream>
#include <bits./stdc++.h>
#include <algorithm>
using namespace std;
class Universe{
private:
    string state;
    char **grid;
    char **newgrid;
    int counting;
public:
    Universe() {
        counting=0;
        int rows = 22;
        int cols = 22;
        grid = new char *[rows];
        for (int i = 0; i < rows; i++) {
            grid[i] = new char[cols];
        }
        newgrid = new char *[rows];
        for (int i = 0; i < rows; i++) {
            newgrid[i] = new char[cols];
        }

    } // initializing the two 2d arrays we are going to use
    void initialize();
    void reset();
    int countNeighbors();
    void nextGeneration();
    void display();
    void run();
    int counter();
};
int Universe:: counter(){
    counting++;
    return counting;
} // function to help the program identify which grid we are using while switching grids to get the next generation
void Universe::initialize() {
    std::srand(static_cast<unsigned int>(std::time(0)));//seeding the rng
    vector<char> vec = {'A', 'D'};
    for (int i = 0; i < 22; ++i) {
        for (int j = 0; j < 22; ++j) {
            if (i == 0 || j == 0 || i == 21 || j == 21) {
                grid[i][j] = 'D';
            } else {
                char letter = vec[rand() % vec.size()]; // here i am using a random number generator set in the vector that contains the state of the cell,so that i can get a different stat (or the same) everytime
                grid[i][j] = letter;
            }
        }
    }
    for (int i = 1; i < 21; ++i) {
        for (int j = 1; j < 21; ++j) {
            cout << grid[i][j] << " ";
        }
        cout << "\n";
    }
} // displaying the initial state of the grid
void Universe::reset() {
    for (int i = 1; i < 21; ++i) {
        for (int j = 0; j < 21; ++j) {
            grid[i][j] = 'D';
        }
    }
    for (int i = 1; i < 21; ++i) {
        for (int j = 0; j < 21; ++j) {
            newgrid[i][j] = 'D';
        }
    }
} // resetting both grids to DEAD
int Universe::countNeighbors() {
    cout << "if you want to count all alive neighbors press 1 : \n";
    cout << "if you want to count all alive neighbors of a particular cell press 2: \n";
    int choice;
    cout << "please enter your choice here : ";
    cin >> choice;
    if (choice == 1) {
        int currentcou=counter();
        int count = 0;
        if(currentcou%2!=0) { // checking to see what grid i am on
            for (int i = 1; i < 21; ++i) {
                for (int j = 1; j < 21; ++j) {
                    if (grid[i][j] == 'A') {
                        count++;
                    }
                } // counting all the alive cells.
            }counter();
        }else {
            for (int i = 1; i < 21; ++i) {
                for (int j = 1; j < 21; ++j) {
                    if (newgrid[i][j] == 'A') {
                        count++;
                    }
                }
            }counter();
        }
        return count;
    } else if (choice == 2) { // checking the alive neighbors of a particular cell
        cout << "please enter the row number and the column number of the desired cell\n";
        int row;
        cout << "row : ";
        cin >> row;
        int column;
        cout << "column : "; // getting the exact coordinates of the desired cell we want to check
        cin >> column;
        int count = 0;
        int currentcou=counter(); // checking to see what grid i am on
        if (currentcou % 2 != 0) { // in those next 55 lines i am checking the neighbors state(left,right up,down,and the diagonals).
            if (grid[row + 1][column] == 'A') {
                count++;
            }
            if (grid[row][column + 1] == 'A') {
                count++;
            }
            if (grid[row - 1][column] == 'A') {
                count++;
            }
            if (grid[row][column - 1] == 'A') {
                count++;
            }
            if (grid[row - 1][column - 1] == 'A') {
                count++;
            }
            if (grid[row + 1][column - 1] == 'A') {
                count++;
            }
            if (grid[row + 1][column + 1] == 'A') {
                count++;
            }
            if (grid[row - 1][column + 1] == 'A') {
                count++;
            }
            counter();
        } else {
            if (newgrid[row + 1][column] == 'A') {
                count++;
            }
            if (newgrid[row][column + 1] == 'A') {
                count++;
            }
            if (newgrid[row - 1][column] == 'A') {
                count++;
            }
            if (newgrid[row][column - 1] == 'A') {
                count++;
            }
            if (newgrid[row - 1][column - 1] == 'A') {
                count++;
            }
            if (newgrid[row + 1][column - 1] == 'A') {
                count++;
            }
            if (newgrid[row + 1][column + 1] == 'A') {
                count++;
            }
            if (newgrid[row - 1][column + 1] == 'A') {
                count++;
            }
            counter();
        }
        return count;
    }
}
void Universe::nextGeneration() { // in this function , i am transforming the current cells to the next generation
    int currentcou=counter(); // checking to see what grid i am on
    for (int i = 1; i < 21; ++i) {// in those next 55 lines i am checking the neighbors state so that i can decide the fate of the selected cell(left,right up,down,and the diagonals).
        for (int j = 1; j < 21; ++j) {
            int count = 0;
            if (currentcou % 2 != 0) {
                if (grid[i + 1][j] == 'A') {
                    count++;
                }
                if (grid[i][j + 1] == 'A') {
                    count++;
                }
                if (grid[i - 1][j] == 'A') {
                    count++;
                }
                if (grid[i][j - 1] == 'A') {
                    count++;
                }
                if (grid[i - 1][j - 1] == 'A') {
                    count++;
                }
                if (grid[i + 1][j - 1] == 'A') {
                    count++;
                }
                if (grid[i + 1][j + 1] == 'A') {

                    count++;
                }
                if (grid[i - 1][j + 1] == 'A') {
                    count++;
                }
                if (count==2&&grid[i][j]=='D'){
                    newgrid[i][j]='D';
                }
                if (count < 2) {
                    newgrid[i][j] = 'D';
                }
                if ((count == 2 || count == 3) && (grid[i][j] == 'A')) {
                    newgrid[i][j] = 'A';
                }
                if (count > 3) {
                    newgrid[i][j] = 'D';
                }
                if (grid[i][j] == 'D' && count == 3) {
                    newgrid[i][j] = 'A';
                }
            }else{
                if (newgrid[i + 1][j] == 'A') {
                    count++;
                }
                if (newgrid[i][j + 1] == 'A') {
                    count++;
                }
                if (newgrid[i - 1][j] == 'A') {
                    count++;
                }
                if (newgrid[i][j - 1] == 'A') {
                    count++;
                }
                if (newgrid[i - 1][j - 1] == 'A') {
                    count++;
                }
                if (newgrid[i + 1][j - 1] == 'A') {
                    count++;
                }
                if (newgrid[i + 1][j + 1] == 'A') {

                    count++;
                }
                if (newgrid[i - 1][j + 1] == 'A') {
                    count++;
                }
                if (count==2&&newgrid[i][j]=='D'){
                    grid[i][j]='D';
                }
                if (count < 2) {
                    grid[i][j] = 'D';
                }
                if ((count == 2 || count == 3) && (newgrid[i][j] == 'A')) {
                    grid[i][j] = 'A';
                }
                if (count > 3) {
                    grid[i][j] = 'D';
                }
                if (newgrid[i][j] == 'D' && count == 3) {
                    grid[i][j] = 'A';
                }
            }

        }

    }
}


void Universe::display() {
    counter();
    int currentcou=counter();
    if(currentcou%2!=0) {// checking to see what grid i am on
        for (int i = 1; i < 21; ++i) {
            for (int j = 1; j < 21; ++j) {
                cout << newgrid[i][j] << " ";
            }
            cout<<"\n";
        }
    }
    else{
        for (int i = 1; i <21 ; ++i) {
            for (int j = 1; j < 21; ++j) {
                cout << grid[i][j] << " ";
            }
            cout<<"\n";
        }
    }
}// here i am just displaying the 2d array
void Universe::run() { // running the code
    Universe uni;
    int runs;
    cout<<"please enter how many times do you want to run the game : ";cin>>runs;
    uni.initialize();
    while(runs!=0){
        cout<<"if you want to start a round please write start :  \n";
        cout<<"if you want to reset the game please write reset : \n";
        cout<<"if you want to count the alive neighbors please write count : \n";
        cout<<"if you want to exit write exit : \n";
        string answer;cout<<"please enter your answer here : " ;cin>>answer;
        if(answer=="start"){
            uni.nextGeneration();
            uni.display();
            runs--;
        }
        else if(answer=="reset"){
            uni.reset();
        }
        else if(answer=="count"){
            cout<<uni.countNeighbors()<<"\n";
        }
        else if(answer=="exit"){
            runs=0;
        }
    }
    cout<<"thank tou for your time ";
}



int main() {
    Universe uni;
    cout<<"welcome to the game of life \n";
    cout<<"do you want to start the game(yes,no) : \n";string answer;cin>>answer;
    if(answer=="yes"){
        uni.run();
    }
    else
        cout<<"have a good day" ;



}